const LogoutButton = ({data})=>{
  return(
    <button onClick={data}>LOGOUT</button>
  )
}

export default LogoutButton