const LoginButton = ({data})=>{
  return(
    <button onClick={data}>LOGIN</button>
  )
}

export default LoginButton