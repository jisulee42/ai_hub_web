리엑트 시작하기


npx create-react-app <폴더 이름>
 *주의 사항*
 폴더 이름에 대문자 혹은 띄어쓰기가 있으면 안됩니다!


다음과 같이 뜬다면?
We suggest that you begin by typing:

  cd react-project
  npm start

Happy hacking!



-> cd <폴더 이름>
-> npm start


